import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronRight, Download, Zap, Shield, Code, Sparkles, Github } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-900/20 via-black to-black"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-500/10 rounded-full filter blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-500/10 rounded-full filter blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Zap className="h-8 w-8 text-red-500" />
              <div className="absolute inset-0 text-red-500 animate-ping opacity-50">
                <Zap className="h-8 w-8" />
              </div>
            </div>
            <span className="text-2xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-red-500">
              ZENITH HUB
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-sm hover:text-red-400 transition-colors">
              Features
            </Link>
            <Link href="#scripts" className="text-sm hover:text-red-400 transition-colors">
              Scripts
            </Link>
            <Link href="#testimonials" className="text-sm hover:text-red-400 transition-colors">
              Testimonials
            </Link>
            <Link href="#faq" className="text-sm hover:text-red-400 transition-colors">
              FAQ
            </Link>
          </nav>
          <Button
            variant="outline"
            className="hidden md:flex border-red-500 text-red-500 hover:bg-red-500/10 hover:text-white transition-all duration-300"
          >
            <Github className="mr-2 h-4 w-4" />
            GitHub
          </Button>
          <Button
            variant="outline"
            className="md:hidden border-red-500 text-red-500 hover:bg-red-500/10 hover:text-white transition-all duration-300 p-2"
          >
            <Github className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-block px-3 py-1 mb-6 text-xs font-medium text-red-500 bg-red-500/10 rounded-full border border-red-500/20 animate-pulse">
              The Ultimate Roblox Script Hub
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Elevate Your <span className="text-red-500">Roblox</span> Experience
            </h1>
            <p className="text-lg md:text-xl text-white/70 mb-8 max-w-2xl mx-auto">
              Zenith Hub provides powerful, undetected scripts for your favorite Roblox games with a sleek, modern
              interface.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white shadow-lg shadow-red-500/30 hover:shadow-red-500/50 transition-all duration-300 group">
                Download Now
                <Download className="ml-2 h-4 w-4 group-hover:translate-y-0.5 transition-transform" />
              </Button>
              <Button variant="outline" className="border-white/20 hover:bg-white/5 transition-all duration-300">
                Learn More
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Floating elements */}
        <div className="absolute top-1/4 left-10 w-20 h-20 border border-white/10 rounded-lg rotate-12 animate-float opacity-30"></div>
        <div
          className="absolute bottom-1/4 right-10 w-16 h-16 border border-red-500/20 rounded-lg -rotate-12 animate-float opacity-30"
          style={{ animationDelay: "1s" }}
        ></div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative z-10 py-20 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-white/70 max-w-2xl mx-auto">
              Zenith Hub comes packed with features designed to enhance your gameplay experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Shield className="h-10 w-10 text-red-500" />,
                title: "Undetected & Secure",
                description: "Our scripts use advanced bypasses to remain undetected by Roblox's anti-cheat systems.",
              },
              {
                icon: <Zap className="h-10 w-10 text-red-500" />,
                title: "Regular Updates",
                description: "We constantly update our scripts to ensure compatibility with the latest game updates.",
              },
              {
                icon: <Code className="h-10 w-10 text-red-500" />,
                title: "Custom Functions",
                description: "Create and customize your own functions to tailor the experience to your needs.",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:border-red-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/10 group"
              >
                <div className="mb-4 relative">
                  {feature.icon}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <Sparkles className="h-10 w-10 text-red-400 animate-pulse" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Script Showcase */}
      <section id="scripts" className="relative z-10 py-20 border-t border-white/10 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Scripts</h2>
            <p className="text-white/70 max-w-2xl mx-auto">
              Browse our collection of premium scripts for popular Roblox games.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Phantom Forces",
                description: "Aimbot, ESP, Silent Aim, and more for Phantom Forces.",
                image: "/placeholder.svg?height=200&width=300",
                popular: true,
              },
              {
                title: "Adopt Me",
                description: "Auto-farm, teleport, and pet simulator for Adopt Me.",
                image: "/placeholder.svg?height=200&width=300",
                popular: false,
              },
              {
                title: "Blox Fruits",
                description: "Auto-farm, auto-quest, and combat assistance for Blox Fruits.",
                image: "/placeholder.svg?height=200&width=300",
                popular: true,
              },
            ].map((script, index) => (
              <div
                key={index}
                className={cn(
                  "group relative bg-gradient-to-b from-white/5 to-transparent backdrop-blur-sm border border-white/10 rounded-xl overflow-hidden hover:border-red-500/50 transition-all duration-300",
                  script.popular ? "ring-1 ring-red-500/50" : "",
                )}
              >
                {script.popular && (
                  <div className="absolute top-3 right-3 z-10 bg-red-500 text-xs font-medium px-2 py-1 rounded-full">
                    Popular
                  </div>
                )}
                <div className="h-40 overflow-hidden">
                  <img
                    src={script.image || "/placeholder.svg"}
                    alt={script.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{script.title}</h3>
                  <p className="text-white/70 mb-4">{script.description}</p>
                  <Button
                    variant="outline"
                    className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10 hover:text-white transition-all duration-300"
                  >
                    View Details
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" className="border-white/20 hover:bg-white/5 transition-all duration-300">
              View All Scripts
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="relative z-10 py-20 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Users Say</h2>
            <p className="text-white/70 max-w-2xl mx-auto">
              Don't just take our word for it. Here's what our community has to say.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                quote:
                  "Zenith Hub has completely changed how I play. The scripts are undetected and the UI is so clean!",
                author: "GameMaster99",
                role: "Premium User",
              },
              {
                quote: "Best script hub I've ever used. Regular updates and the support team is always helpful.",
                author: "RobloxPro2023",
                role: "VIP Member",
              },
              {
                quote: "I've tried many script hubs, but Zenith is on another level. Worth every penny!",
                author: "ScriptKing",
                role: "Beta Tester",
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:border-red-500/50 transition-all duration-300"
              >
                <div className="mb-4 text-red-500">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
                    <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                  </svg>
                </div>
                <p className="text-white/80 mb-4 italic">{testimonial.quote}</p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center text-white font-bold">
                    {testimonial.author.charAt(0)}
                  </div>
                  <div className="ml-3">
                    <p className="font-medium">{testimonial.author}</p>
                    <p className="text-xs text-white/60">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="relative z-10 py-20 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-white/70 max-w-2xl mx-auto">Got questions? We've got answers.</p>
          </div>

          <div className="max-w-3xl mx-auto">
            {[
              {
                question: "Is Zenith Hub safe to use?",
                answer:
                  "Yes, Zenith Hub is designed with security in mind. Our scripts use advanced bypasses to remain undetected by Roblox's anti-cheat systems.",
              },
              {
                question: "How often do you update the scripts?",
                answer:
                  "We update our scripts regularly to ensure compatibility with the latest game updates. Premium users get priority access to updates.",
              },
              {
                question: "Do you offer a free trial?",
                answer:
                  "Yes, we offer a limited free trial with basic features. To access all premium features, you'll need to purchase a subscription.",
              },
              {
                question: "How do I install Zenith Hub?",
                answer:
                  "Installation is simple. Download the launcher from our website, run it, and follow the on-screen instructions. Our detailed guide will walk you through the process.",
              },
            ].map((faq, index) => (
              <div
                key={index}
                className="mb-4 border border-white/10 rounded-lg hover:border-red-500/50 transition-all duration-300"
              >
                <button className="flex justify-between items-center w-full p-4 text-left font-medium">
                  <span>{faq.question}</span>
                  <ChevronRight className="h-5 w-5 text-red-500" />
                </button>
                <div className="p-4 pt-0 text-white/70">
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 py-20 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-red-900/20 to-black rounded-2xl p-8 md:p-12 border border-red-500/20 backdrop-blur-sm">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Elevate Your Gameplay?</h2>
              <p className="text-white/70 max-w-2xl mx-auto">
                Join thousands of satisfied users and experience Roblox like never before.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 text-white shadow-lg shadow-red-500/30 hover:shadow-red-500/50 transition-all duration-300 group">
                Download Now
                <Download className="ml-2 h-4 w-4 group-hover:translate-y-0.5 transition-transform" />
              </Button>
              <Button variant="outline" className="border-white/20 hover:bg-white/5 transition-all duration-300">
                View Documentation
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-12 border-t border-white/10 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Zap className="h-6 w-6 text-red-500" />
                <span className="text-xl font-bold tracking-tighter">ZENITH HUB</span>
              </div>
              <p className="text-white/60 text-sm mb-4">The ultimate script hub for Roblox enthusiasts.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-white/60 hover:text-red-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </a>
                <a href="#" className="text-white/60 hover:text-red-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                </a>
                <a href="#" className="text-white/60 hover:text-red-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
                <a href="#" className="text-white/60 hover:text-red-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                    <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
                  </svg>
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-bold mb-4">Products</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Zenith Hub
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Script API
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Custom Scripts
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Premium Access
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Tutorials
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Community
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/60 text-sm">© {new Date().getFullYear()} Zenith Hub. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-white/60 hover:text-red-500 transition-colors text-sm">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

